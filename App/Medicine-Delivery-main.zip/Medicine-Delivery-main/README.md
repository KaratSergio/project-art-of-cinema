# Medicine-Delivery
Medicine Delivery app

```
1. Clone repo with github:  git clone https://github.com/Vitaliy-Mazurenko/Medicine-Delivery.git

2. Go to server project folder(backend), install dependencies and run server: npm start
   Now you have a backend for application. Go to the url: http://localhost:4000/

3. Go to client project folder(frontend), install dependencies and run client: npm run dev
   Now you have a frontend for application. Go to the url: http://localhost:5173/
   
```
